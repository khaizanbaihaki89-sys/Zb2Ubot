"""Pondasi kategori administrasi."""
